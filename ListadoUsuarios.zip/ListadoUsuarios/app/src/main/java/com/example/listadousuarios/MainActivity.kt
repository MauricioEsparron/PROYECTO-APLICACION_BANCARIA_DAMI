package com.example.listadousuarios


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import com.example.listadousuarios.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private var usuarios = emptyArray<String>()
    lateinit var arrayAdapter: ArrayAdapter<*>
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val usuarios = arrayOf(
            "Código:U001 " +
                    "\nNombre:Juan Pérez " +
                    "\nClave:Jperez123" +
                    "\nTipo de Usuario:Cliente " +
                    "\nEstado:Activo ",
            "Código:U002 " +
                    "\nNombre:Ana Rodríguez " +
                    "\nClave:Arodriguez101 " +
                    "\nTipo de Usuario:Cliente " +
                    "\nEstado:Activo ",
            "Código:U003 " +
                    "\nNombre:Luis Hernández " +
                    "\nClave:Lhernandez202 " +
                    "\nTipo de Usuario:Cliente " +
                    "\nEstado:Activo ",
            "Código:U004 " +
                    "\nNombre:Patricia Martínez " +
                    "\nClave:Pmartinez303 " +
                    "\nTipo de Usuario:Cliente " +
                    "\nEstado:Activo ",
            "Código:U005 " +
                    "\nNombre:Laura Díaz " +
                    "\nClave:Ldiaz505 " +
                    "\nTipo de Usuario:Cliente " +
                    "\nEstado:Activo "
        )

        var itemsAdapter = ArrayAdapter<String>(MainActivity@this, android.R.layout.simple_list_item_1,usuarios)
        binding.listaUsuarios.adapter = itemsAdapter
    }
}